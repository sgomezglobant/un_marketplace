// vender.controller.js
angular.module('starter').controller('VenderCtrl', function(){

});