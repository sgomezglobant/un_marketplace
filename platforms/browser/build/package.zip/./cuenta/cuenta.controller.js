// cuenta.controller.js
angular.module('starter').controller('CuentaCtrl', function(){

});